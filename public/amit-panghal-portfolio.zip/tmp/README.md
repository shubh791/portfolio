# Amit Panghal – Cybersecurity Portfolio

A dark, terminal-themed portfolio website built with Next.js, TailwindCSS, and shadcn/ui.

## Tech Stack
- **Framework:** Next.js 14 (App Router)
- **Styling:** TailwindCSS + Custom CSS animations
- **Components:** shadcn/ui
- **Icons:** Lucide React
- **Font:** JetBrains Mono + Inter (Google Fonts)

## Features
- Matrix rain canvas animation (Hero)
- Typing animation cycling through roles
- Custom hexagonal SVG logo (AP)
- Premium frosted-glass navbar with numbered links
- Glassmorphism cards throughout
- Experience timeline
- Skills arsenal grouped by category
- Projects, Certifications, Publications, Education sections
- Professional branding footer
- Smooth scroll with active section tracking
- Fully responsive (mobile + desktop)

## Quick Start

1. Install dependencies:
```bash
yarn install
```

2. Create `.env` file:
```
MONGO_URL=mongodb://localhost:27017
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```

3. Run development server:
```bash
yarn dev
```

4. Open [http://localhost:3000](http://localhost:3000)

## Customisation
All profile data is in `/app/app/page.js` — look for the `// ─── DATA ───` section at the top.
Change `EXPERIENCE`, `SKILLS`, `PROJECTS`, `CERTIFICATIONS`, `PUBLICATIONS`, `EDUCATION` arrays to update content.

## Structure
```
app/
├── app/
│   ├── page.js          # Main portfolio page (all components + data)
│   ├── layout.js        # Root layout + metadata + favicon
│   ├── globals.css      # Global styles + custom animations
│   └── api/             # API routes (minimal, portfolio is static)
├── components/ui/       # shadcn/ui components
├── tailwind.config.js
└── package.json
```
