import './globals.css'

export const metadata = {
  title: 'Amit Panghal | Security Researcher',
  description: 'Security Researcher @ Altered Security | CRTP | Security+ | CTFing @ Sid3Chann3l | Perpetual Student',
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'><polygon points='24,2 44,13 44,35 24,46 4,35 4,13' stroke='%2300ff41' stroke-width='2' fill='none'/><text x='10' y='31' font-family='monospace' font-size='17' font-weight='700' fill='%2300ff41'>AP</text></svg>",
  }
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <script dangerouslySetInnerHTML={{__html:'window.addEventListener("error",function(e){if(e.error instanceof DOMException&&e.error.name==="DataCloneError"&&e.message&&e.message.includes("PerformanceServerTiming")){e.stopImmediatePropagation();e.preventDefault()}},true);'}} />
      </head>
      <body className="bg-black text-white antialiased">
        {children}
      </body>
    </html>
  )
}
