'use client'

import { useState, useEffect, useRef } from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import {
  Shield, Terminal, Code2, Cpu, Flag, GraduationCap, Award, BookOpen,
  MapPin, Linkedin, Globe, ExternalLink, ChevronDown, Menu, X,
  Lock, Eye, Target, Calendar, Clock, FileText, Languages, ChevronRight, Mail
} from 'lucide-react'

// ─── DATA ─────────────────────────────────────────────────────────────────────

const NAV_LINKS = [
  { id: 'about', label: 'About' },
  { id: 'experience', label: 'Experience' },
  { id: 'skills', label: 'Skills' },
  { id: 'projects', label: 'Projects' },
  { id: 'certifications', label: 'Certs' },
  { id: 'publications', label: 'Research' },
  { id: 'education', label: 'Education' },
  { id: 'contact', label: 'Contact' },
]

const TYPING_STRINGS = [
  'Security Researcher',
  'Red Team Operator',
  'CTF Player @ Sid3Chann3l',
  'Windows Internals Enthusiast',
  'Perpetual Student',
  'Implant Developer',
]

const EXPERIENCE = [
  {
    company: 'Altered Security',
    type: 'Full-time · 1 yr 1 mo · Remote',
    color: '#00ff41',
    icon: Shield,
    roles: [
      {
        title: 'Security Researcher',
        duration: 'Jul 2025 – Present · 9 mos',
        desc: 'Working on CETP (Certified Enterprise Threat Professional) and advanced security research in enterprise environments.',
        tags: ['CETP', 'Security Research', 'Windows Internals'],
      },
      {
        title: 'Junior Security Researcher',
        duration: 'Mar 2025 – Jul 2025 · 5 mos',
        desc: 'Worked on CRTE (Certified Red Team Expert) content and research for enterprise red team operations.',
        tags: ['CRTE', 'Red Team', 'Enterprise Security'],
      },
    ],
  },
  {
    company: 'P.I.V.O.T Security',
    type: 'Internship · 1 yr 4 mos · New Delhi, India · Remote',
    color: '#00ffff',
    icon: Target,
    roles: [
      {
        title: 'Implant Development Intern',
        duration: 'Aug 2024 – Jan 2025 · 6 mos',
        desc: 'Worked on STEP (Simulated Threat Engagement Platform). Implemented ransomware and APT simulation architecture for reliable Adversary Emulation.',
        tags: ['STEP', 'Adversary Emulation', 'APT Simulation', 'Ransomware Research'],
      },
      {
        title: 'Red Team Intern (R&D)',
        duration: 'Oct 2023 – Aug 2024 · 11 mos',
        desc: 'Wrote internal C++ & C# Offensive Security Tools from the ground up utilizing GitLab CI for randomization and obfuscation. Integrated telemetry blocking workflows for enhanced OPSEC.',
        tags: ['C++', 'C#', 'GitLab CI', 'OPSEC', 'Obfuscation', 'C2'],
      },
    ],
  },
  {
    company: 'Sid3Chann3l',
    type: 'CTF Team · 2 yrs 11 mos',
    color: '#bf5af2',
    icon: Flag,
    roles: [
      {
        title: 'CTF Player',
        duration: 'Mar 2022 – Jan 2025 · 2 yrs 11 mos',
        desc: 'Participated in Capture The Flag competitions and contributed to major milestones achieved as a team. Specialised in binary exploitation, reverse engineering, and Windows challenges.',
        tags: ['CTF', 'Binary Exploitation', 'Reverse Engineering', 'Team Collaboration'],
      },
    ],
  },
]

const SKILLS = {
  'Offensive Security': { color: '#00ff41', skills: ['Red Teaming', 'Adversary Emulation', 'APT Simulation', 'OPSEC', 'Implant Development', 'C2 Infrastructure', 'CRTP', 'CRTE'] },
  'Windows Internals': { color: '#00ffff', skills: ['Windows Kernel', 'Driver Development', 'WinDbg Debugging', 'Process Injection', 'NTAPI', 'ETW/Telemetry Bypass', 'Registry Internals'] },
  'Programming': { color: '#bf5af2', skills: ['C++', 'C#', 'PowerShell', 'Python', 'Assembly (x86/x64)'] },
  'Tools & Platforms': { color: '#f59e0b', skills: ['GitLab CI', 'Cobalt Strike', 'Metasploit', 'IDA Pro', 'WinDbg', 'Ghidra', 'Binary Ninja'] },
  'Certifications': { color: '#ef4444', skills: ['CRTP', 'Security+', 'Offensive Driver Dev', 'Advanced WinDbg'] },
}

const PROJECTS = [
  {
    title: 'Stochastic Optimization of System Wide Performance Characteristics in WindowsOS using PowerShell',
    duration: 'May 2022 – Present',
    association: 'Sid3Chann3l',
    desc: 'Optimization script for WindowsOS written in PowerShell, employing basic Multi-Layer Perceptron (MLP), fully automating Diagnosis, and Remediation of Performance, Stability and Security issues.',
    tags: ['PowerShell', 'Machine Learning', 'MLP', 'Windows', 'Automation'],
    icon: Cpu,
    color: '#00ff41',
  },
  {
    title: 'STEP – Simulated Threat Engagement Platform',
    duration: 'Aug 2024 – Jan 2025',
    association: 'P.I.V.O.T Security',
    desc: 'Contributed to STEP platform for simulating sophisticated threat scenarios including ransomware and APT architectures to enable reliable Adversary Emulation.',
    tags: ['Adversary Emulation', 'APT', 'Threat Simulation', 'Ransomware Research'],
    icon: Target,
    color: '#00ffff',
  },
  {
    title: 'Internal C++ & C# Offensive Security Tooling',
    duration: 'Oct 2023 – Aug 2024',
    association: 'P.I.V.O.T Security',
    desc: 'Built internal offensive security tools from scratch in C++ and C#, leveraging GitLab CI for automated randomization, obfuscation, and OPSEC via telemetry blocking.',
    tags: ['C++', 'C#', 'OST Development', 'CI/CD', 'OPSEC', 'Obfuscation'],
    icon: Code2,
    color: '#bf5af2',
  },
]

const CERTIFICATIONS = [
  {
    name: 'Offensive Driver Development',
    issuer: 'Zero-Point Security Ltd',
    issued: 'Jun 2025',
    credentialId: '8xuxfgyfrf',
    color: '#00ff41',
    icon: Shield,
    desc: 'Advanced kernel-level offensive driver development for red team operations and EDR evasion.',
  },
  {
    name: 'Debuggers 2011: Intermediate WinDbg',
    issuer: 'OpenSecurityTraining2',
    issued: 'Apr 2025',
    credentialId: '888b24e602e14640b7f...',
    color: '#00ffff',
    icon: Terminal,
    desc: 'Intermediate Windows debugging with WinDbg, covering kernel debugging and crash analysis.',
  },
  {
    name: 'CRTP – Certified Red Team Professional',
    issuer: 'Altered Security',
    issued: '2024',
    credentialId: null,
    color: '#bf5af2',
    icon: Target,
    desc: 'Certified in Active Directory attacks and enterprise red team operations.',
  },
  {
    name: 'Security+',
    issuer: 'CompTIA',
    issued: '2023',
    credentialId: null,
    color: '#f59e0b',
    icon: Lock,
    desc: 'Foundation-level cybersecurity certification covering network security, threats, and cryptography.',
  },
]

const PUBLICATIONS = [
  {
    title: 'GGs – Farewell to ADCS',
    source: 'Tx0actical.github.io',
    date: 'Apr 6, 2023',
    desc: 'CTF Writeup for the Challenge "GGs" Under the "Aerocapture the Flag" Category in Hack-a-Sat 4. Orbital Mechanics in action!',
    tags: ['CTF', 'Hack-a-Sat 4', 'Orbital Mechanics', 'ADCS'],
    url: 'https://tx0actical.github.io',
    color: '#00ff41',
  },
  {
    title: '0x02 Advanced Windows Internals',
    source: 'Tx0actical.github.io',
    date: 'Mar 24, 2023',
    desc: 'A detailed technical overview of WindowsOS Internals, covering kernel mechanisms, memory management, and process architecture.',
    tags: ['Windows Internals', 'Kernel', 'Technical Research'],
    url: 'https://tx0actical.github.io',
    color: '#00ffff',
  },
]

const EDUCATION = [
  {
    institution: 'Chandigarh University',
    degree: 'Bachelor of Technology – BTech, Computer Science',
    duration: 'Sep 2021 – May 2025',
    color: '#00ff41',
    icon: GraduationCap,
    courses: ['Advanced Computer Architecture', 'Data Structures & Algorithms', 'Operating Systems', 'Computer Networks'],
  },
  {
    institution: 'Sainik School Kunjpura',
    degree: 'Secondary & Senior Secondary Education',
    duration: 'Mar 2016 – Jun 2020',
    color: '#f59e0b',
    icon: BookOpen,
    courses: ['Science & Mathematics', 'Discipline & Leadership'],
  },
]

// ─── COMPONENTS ───────────────────────────────────────────────────────────────

function MatrixRain() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener('resize', resize)

    const chars = '01アイウエオカキクケコABCDEFGHIJKLMNOPQRSTUVWXYZ<>{}[]|/\\~!@#$%^&*()'
    const fontSize = 14
    const drops = Array(Math.floor(window.innerWidth / fontSize)).fill(1)

    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.font = `${fontSize}px monospace`
      ctx.shadowBlur = 4
      ctx.shadowColor = '#00ff41'

      for (let i = 0; i < drops.length; i++) {
        const char = chars[Math.floor(Math.random() * chars.length)]
        ctx.fillStyle = Math.random() > 0.7 ? '#00ffff' : '#00ff41'
        ctx.globalAlpha = Math.random() > 0.5 ? 1 : 0.4
        ctx.fillText(char, i * fontSize, drops[i] * fontSize)
        ctx.globalAlpha = 1
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0
        drops[i]++
      }
    }

    const interval = setInterval(draw, 40)
    return () => {
      clearInterval(interval)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-20" style={{ zIndex: 0 }} />
}

function TypingAnimation({ strings }) {
  const [display, setDisplay] = useState('')
  const [strIdx, setStrIdx] = useState(0)
  const [charIdx, setCharIdx] = useState(0)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const target = strings[strIdx]
    let timeout

    if (!deleting && charIdx < target.length) {
      timeout = setTimeout(() => {
        setDisplay(target.slice(0, charIdx + 1))
        setCharIdx(c => c + 1)
      }, 80)
    } else if (!deleting && charIdx === target.length) {
      timeout = setTimeout(() => setDeleting(true), 2500)
    } else if (deleting && charIdx > 0) {
      timeout = setTimeout(() => {
        setDisplay(target.slice(0, charIdx - 1))
        setCharIdx(c => c - 1)
      }, 50)
    } else if (deleting && charIdx === 0) {
      setDeleting(false)
      setStrIdx(i => (i + 1) % strings.length)
    }

    return () => clearTimeout(timeout)
  }, [charIdx, deleting, strIdx, strings])

  return (
    <span className="font-mono text-neon-green text-glow-green">
      {display}<span className="animate-pulse text-neon-green">|</span>
    </span>
  )
}

// ─── LOGO SVG ICON ────────────────────────────────────────────────────────────
function LogoIcon({ size = 32, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`logo-glow ${className}`}
    >
      {/* Outer hexagon */}
      <polygon
        points="24,2 44,13 44,35 24,46 4,35 4,13"
        stroke="#00ff41"
        strokeWidth="1.5"
        fill="none"
        opacity="0.7"
      />
      {/* Inner hexagon */}
      <polygon
        points="24,7 39,15.5 39,32.5 24,41 9,32.5 9,15.5"
        stroke="#00ff41"
        strokeWidth="0.8"
        fill="#00ff41"
        fillOpacity="0.06"
        opacity="0.5"
      />
      {/* Corner accent dots */}
      <circle cx="24" cy="2" r="1.5" fill="#00ff41" opacity="0.9" />
      <circle cx="44" cy="13" r="1.5" fill="#00ffff" opacity="0.7" />
      <circle cx="44" cy="35" r="1.5" fill="#00ff41" opacity="0.7" />
      <circle cx="24" cy="46" r="1.5" fill="#00ffff" opacity="0.9" />
      <circle cx="4" cy="35" r="1.5" fill="#00ff41" opacity="0.7" />
      <circle cx="4" cy="13" r="1.5" fill="#00ffff" opacity="0.7" />
      {/* "A" letter */}
      <text
        x="10"
        y="31"
        fontFamily="'JetBrains Mono', monospace"
        fontSize="18"
        fontWeight="700"
        fill="#00ff41"
        letterSpacing="-1"
      >
        AP
      </text>
      {/* Bottom terminal cursor bar */}
      <rect x="14" y="35" width="20" height="1.5" fill="#00ff41" opacity="0.5" rx="1" />
      {/* Scan line accent */}
      <line x1="4" y1="24" x2="44" y2="24" stroke="#00ff41" strokeWidth="0.4" opacity="0.2" />
    </svg>
  )
}

function NavBar({ activeSection }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMenuOpen(false)
  }

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled
        ? 'py-0 border-b border-white/5'
        : 'bg-transparent py-0'
    }`}
    style={scrolled ? {
      background: 'rgba(0,0,0,0.85)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      boxShadow: '0 1px 0 rgba(0,255,65,0.15), 0 4px 24px rgba(0,0,0,0.6)',
    } : {}}>

      {/* Top accent line - only when scrolled */}
      {scrolled && (
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{ background: 'linear-gradient(90deg, transparent 0%, #00ff4160 25%, #00ffff80 50%, #00ff4160 75%, transparent 100%)' }} />
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">

          {/* ── LOGO ── */}
          <button onClick={() => scrollTo('hero')} className="flex items-center gap-3 group">
            <LogoIcon size={36} />
            <div className="flex flex-col items-start leading-none">
              <span className="font-mono font-bold text-white tracking-wider text-sm group-hover:text-neon-green transition-colors duration-200">
                AMIT PANGHAL
              </span>
              <span className="font-mono text-neon-green/60 text-xs tracking-widest mt-0.5 group-hover:text-neon-green/90 transition-colors">
                SEC.RESEARCHER
              </span>
            </div>
          </button>

          {/* ── CENTER NAV ── */}
          <div className="hidden md:flex items-center">
            {NAV_LINKS.map((link, i) => {
              const isActive = activeSection === link.id
              return (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className={`relative px-4 py-5 font-mono text-xs tracking-widest uppercase transition-all duration-200 group ${
                    isActive ? 'text-neon-green' : 'text-white/40 hover:text-white/80'
                  }`}
                >
                  {/* Number accent */}
                  <span className={`absolute top-3 left-1/2 -translate-x-1/2 text-[9px] font-mono transition-colors duration-200 ${
                    isActive ? 'text-neon-green/60' : 'text-white/20 group-hover:text-white/40'
                  }`}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  {link.label}
                  {/* Active underline */}
                  {isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full"
                      style={{ background: 'linear-gradient(90deg, #00ff41, #00ffff)', boxShadow: '0 0 8px #00ff41' }} />
                  )}
                  {/* Hover underline */}
                  {!isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-px bg-white/10 scale-x-0 group-hover:scale-x-100 transition-transform duration-200 rounded-full" />
                  )}
                </button>
              )
            })}
          </div>

          {/* ── RIGHT: STATUS + SOCIALS ── */}
          <div className="hidden md:flex items-center gap-4">
            {/* Status badge */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-neon-green/20 bg-neon-green/5">
              <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
              <span className="font-mono text-neon-green text-xs tracking-wider">ONLINE</span>
            </div>

            {/* Divider */}
            <div className="w-px h-6 bg-white/10" />

            {/* Social links */}
            <a href="https://www.linkedin.com/in/amit-panghal/" target="_blank" rel="noopener noreferrer"
              className="w-8 h-8 rounded-lg border border-white/10 flex items-center justify-center text-white/40 hover:text-neon-cyan hover:border-neon-cyan/40 hover:bg-neon-cyan/5 transition-all duration-200">
              <Linkedin size={15} />
            </a>
            <a href="https://tx0actical.github.io" target="_blank" rel="noopener noreferrer"
              className="w-8 h-8 rounded-lg border border-white/10 flex items-center justify-center text-white/40 hover:text-neon-green hover:border-neon-green/40 hover:bg-neon-green/5 transition-all duration-200">
              <Globe size={15} />
            </a>
          </div>

          {/* ── MOBILE HAMBURGER ── */}
          <button className="md:hidden w-10 h-10 rounded-lg border border-white/10 flex items-center justify-center text-white/60 hover:text-neon-green hover:border-neon-green/30 transition-all" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* ── MOBILE MENU ── */}
      {menuOpen && (
        <div className="md:hidden border-t border-white/5 px-4 py-4"
          style={{ background: 'rgba(0,0,0,0.95)', backdropFilter: 'blur(20px)' }}>
          {/* Mobile logo */}
          <div className="flex items-center gap-2 pb-4 mb-4 border-b border-white/5">
            <LogoIcon size={28} />
            <span className="font-mono text-white/60 text-xs">amit-panghal.sec</span>
          </div>
          <div className="grid grid-cols-2 gap-1">
            {NAV_LINKS.map((link, i) => (
              <button key={link.id} onClick={() => scrollTo(link.id)}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-lg font-mono text-xs transition-all ${
                  activeSection === link.id
                    ? 'text-neon-green bg-neon-green/10 border border-neon-green/20'
                    : 'text-white/50 hover:text-neon-green hover:bg-white/5 border border-transparent'
                }`}>
                <span className="text-[10px] opacity-40">{String(i + 1).padStart(2, '0')}</span>
                {link.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3 mt-4 pt-4 border-t border-white/5">
            <a href="https://www.linkedin.com/in/amit-panghal/" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 text-white/40 hover:text-neon-cyan font-mono text-xs transition-colors">
              <Linkedin size={14} />LinkedIn
            </a>
            <a href="https://tx0actical.github.io" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 text-white/40 hover:text-neon-green font-mono text-xs transition-colors">
              <Globe size={14} />Blog
            </a>
          </div>
        </div>
      )}
    </nav>
  )
}

function SectionHeader({ label, title, subtitle }) {
  return (
    <div className="text-center mb-16">
      <p className="font-mono text-neon-green text-sm mb-3 tracking-widest uppercase">
        <span className="text-white/30">// </span>{label}
      </p>
      <h2 className="text-4xl md:text-5xl font-bold mb-4">{title}</h2>
      {subtitle && <p className="text-white/50 max-w-xl mx-auto text-base">{subtitle}</p>}
      <div className="flex items-center justify-center gap-4 mt-6">
        <div className="h-px w-16 bg-gradient-to-r from-transparent to-neon-green/60" />
        <div className="w-2 h-2 rounded-full bg-neon-green glow-green" />
        <div className="h-px w-16 bg-gradient-to-l from-transparent to-neon-green/60" />
      </div>
    </div>
  )
}

function SkillTag({ skill, color = '#00ff41' }) {
  return (
    <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full font-mono text-xs font-medium border transition-all duration-200 hover:scale-105 cursor-default"
      style={{ color, borderColor: `${color}40`, background: `${color}08` }}>
      <span style={{ color, opacity: 0.5 }}>{'>'}</span>{skill}
    </span>
  )
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

export default function App() {
  const [activeSection, setActiveSection] = useState('hero')

  useEffect(() => {
    const sections = ['hero', 'about', 'experience', 'skills', 'projects', 'certifications', 'publications', 'education', 'contact']
    const observers = []
    sections.forEach(id => {
      const el = document.getElementById(id)
      if (!el) return
      const obs = new IntersectionObserver(([entry]) => {
        if (entry.isIntersecting) setActiveSection(id)
      }, { rootMargin: '-40% 0px -40% 0px' })
      obs.observe(el)
      observers.push(obs)
    })
    return () => observers.forEach(obs => obs.disconnect())
  }, [])

  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <NavBar activeSection={activeSection} />

      {/* ── HERO ── */}
      <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <MatrixRain />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black z-10 pointer-events-none" />
        <div className="absolute inset-0 hex-pattern z-5 pointer-events-none" />

        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 glass-green px-4 py-2 rounded-full mb-8 animate-fade-in-up">
            <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
            <span className="font-mono text-neon-green text-sm tracking-wider">Open to Opportunities</span>
          </div>

          <div className="relative inline-block mb-8 animate-fade-in-up delay-100">
            <div className="w-28 h-28 md:w-36 md:h-36 rounded-full border-2 border-neon-green/60 glow-green mx-auto flex items-center justify-center bg-gradient-to-br from-zinc-900 to-black">
              <span className="font-mono text-4xl md:text-5xl font-bold text-neon-green text-glow-green">AP</span>
            </div>
            <div className="absolute -inset-4 rounded-full border border-neon-green/20 animate-spin-slow pointer-events-none" />
            <div className="absolute -inset-8 rounded-full border border-neon-cyan/10 pointer-events-none" style={{ animation: 'spin-slow 15s linear infinite reverse' }} />
          </div>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4 animate-fade-in-up delay-200">
            <span className="text-white">Amit </span>
            <span className="shimmer-text">Panghal</span>
          </h1>

          <div className="text-xl md:text-2xl mb-6 h-9 animate-fade-in-up delay-300">
            <TypingAnimation strings={TYPING_STRINGS} />
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-8 animate-fade-in-up delay-400">
            {['CRTP', 'Security+', 'CTF @ Sid3Chann3l', 'Windows Internals', 'Red Team'].map(b => (
              <span key={b} className="font-mono text-xs px-3 py-1.5 rounded-full border border-neon-green/30 text-neon-green bg-neon-green/5">{b}</span>
            ))}
          </div>

          <p className="text-white/50 flex items-center justify-center gap-2 mb-10 animate-fade-in-up delay-500">
            <MapPin size={14} className="text-neon-green" />
            <span className="font-mono text-sm">New Delhi, Delhi, India</span>
          </p>

          <div className="flex flex-wrap justify-center gap-4 animate-fade-in-up delay-600">
            <Button onClick={() => scrollTo('experience')}
              className="bg-neon-green hover:bg-neon-green/80 text-black font-mono font-bold px-6 py-3 rounded-lg glow-green transition-all hover:scale-105">
              <Terminal size={16} className="mr-2" />View Experience
            </Button>
            <button
              onClick={() => scrollTo('contact')}
              className="btn-touch relative overflow-hidden font-mono font-bold px-6 py-3 rounded-lg border border-neon-cyan/50 text-neon-cyan text-sm transition-all duration-300"
              style={{ background: 'transparent' }}
            >
              <span className="relative z-10 flex items-center gap-2">
                <Mail size={16} />Get in Touch
              </span>
            </button>
          </div>
        </div>

        <button onClick={() => scrollTo('about')}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 text-white/30 hover:text-neon-green transition-colors animate-bounce">
          <ChevronDown size={28} />
        </button>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="01. about_me" title="Who Am I" subtitle="A cybersecurity professional obsessed with offensive security and Windows internals." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="space-y-6">
            <div className="glass rounded-xl p-6 border-l-2 border-neon-green">
              <p className="font-mono text-xs text-neon-green mb-3">$ cat about.txt</p>
              <p className="text-white/80 leading-relaxed text-sm">
                I'm a <span className="text-neon-green font-semibold">Security Researcher at Altered Security</span>, holding certifications in{' '}
                <span className="text-neon-cyan">CRTP</span> and <span className="text-neon-cyan">Security+</span>. My work revolves around red team operations, offensive tooling development, and deep dives into Windows internals.
              </p>
            </div>
            <div className="glass rounded-xl p-6 border-l-2 border-neon-cyan">
              <p className="font-mono text-xs text-neon-cyan mb-3">$ whoami --verbose</p>
              <p className="text-white/80 leading-relaxed text-sm">
                As a <span className="text-neon-purple font-semibold">Perpetual Student</span>, I never stop learning. From developing ransomware simulation architectures to competing in global CTFs with team{' '}
                <span className="text-neon-green font-semibold">Sid3Chann3l</span>, I thrive at the intersection of research and hands-on hacking.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { val: '3+', label: 'Years in Security', icon: Shield, color: '#00ff41' },
              { val: '792', label: 'LinkedIn Followers', icon: Linkedin, color: '#00ffff' },
              { val: '5+', label: 'CTF Competitions', icon: Flag, color: '#bf5af2' },
              { val: '2+', label: 'Publications', icon: FileText, color: '#f59e0b' },
              { val: 'CRTP', label: 'Red Team Certified', icon: Target, color: '#00ff41' },
              { val: 'BTech', label: 'Computer Science', icon: GraduationCap, color: '#00ffff' },
            ].map(({ val, label, icon: Icon, color }) => (
              <div key={label} className="glass rounded-xl p-5 text-center hover:scale-105 transition-transform duration-200 cursor-default" style={{ borderTop: `2px solid ${color}40` }}>
                <Icon size={20} style={{ color }} className="mx-auto mb-2" />
                <p className="font-mono text-2xl font-bold" style={{ color }}>{val}</p>
                <p className="text-white/50 text-xs mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── EXPERIENCE ── */}
      <section id="experience" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="02. experience" title="Work History" subtitle="Building offensive security expertise one red team operation at a time." />
        <div className="relative">
          <div className="hidden md:block absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-neon-green/60 via-neon-cyan/30 to-transparent" />
          <div className="space-y-10">
            {EXPERIENCE.map((exp, i) => (
              <div key={i} className="relative md:pl-20">
                <div className="hidden md:flex absolute left-5 top-6 w-7 h-7 rounded-full items-center justify-center border-2 z-10"
                  style={{ borderColor: exp.color, background: `${exp.color}15` }}>
                  <exp.icon size={13} style={{ color: exp.color }} />
                </div>
                <div className="glass rounded-2xl p-6 transition-all duration-300" style={{ borderLeft: `3px solid ${exp.color}` }}>
                  <div className="mb-5">
                    <h3 className="text-xl font-bold" style={{ color: exp.color }}>{exp.company}</h3>
                    <p className="text-white/40 font-mono text-xs mt-1">{exp.type}</p>
                  </div>
                  <div className="space-y-5">
                    {exp.roles.map((role, j) => (
                      <div key={j} className="pl-4 border-l border-white/10">
                        <div className="flex flex-wrap items-center gap-3 mb-2">
                          <h4 className="font-semibold text-white">{role.title}</h4>
                          <span className="font-mono text-xs text-white/40 flex items-center gap-1"><Calendar size={10} />{role.duration}</span>
                        </div>
                        <p className="text-white/60 text-sm leading-relaxed mb-3">{role.desc}</p>
                        <div className="flex flex-wrap gap-2">
                          {role.tags.map(tag => <SkillTag key={tag} skill={tag} color={exp.color} />)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── SKILLS ── */}
      <section id="skills" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="03. skills" title="Arsenal" subtitle="Tools, languages, and techniques in my offensive security toolkit." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(SKILLS).map(([category, { color, skills }]) => (
            <div key={category} className="glass rounded-2xl p-6 hover:scale-[1.02] transition-all duration-300" style={{ borderTop: `2px solid ${color}40` }}>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-2 h-2 rounded-full" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
                <h3 className="font-mono text-sm font-bold" style={{ color }}>{category}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {skills.map(skill => <SkillTag key={skill} skill={skill} color={color} />)}
              </div>
            </div>
          ))}
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── PROJECTS ── */}
      <section id="projects" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="04. projects" title="Notable Work" subtitle="Selected projects showcasing offensive security research and tool development." />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {PROJECTS.map((proj, i) => (
            <div key={i} className="glass rounded-2xl p-6 flex flex-col hover:scale-[1.02] transition-all duration-300 cursor-default"
              style={{ border: `1px solid ${proj.color}20` }}>
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${proj.color}10`, border: `1px solid ${proj.color}30` }}>
                  <proj.icon size={22} style={{ color: proj.color }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-sm text-white leading-snug mb-1">{proj.title}</h3>
                  <p className="font-mono text-xs" style={{ color: proj.color }}>{proj.association}</p>
                </div>
              </div>
              <span className="font-mono text-xs text-white/30 flex items-center gap-1 mb-3"><Clock size={10} />{proj.duration}</span>
              <p className="text-white/60 text-sm leading-relaxed flex-1 mb-4">{proj.desc}</p>
              <div className="flex flex-wrap gap-2 mt-auto">
                {proj.tags.map(tag => <SkillTag key={tag} skill={tag} color={proj.color} />)}
              </div>
            </div>
          ))}
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── CERTIFICATIONS ── */}
      <section id="certifications" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="05. certifications" title="Credentials" subtitle="Verified expertise in offensive security and Windows internals." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {CERTIFICATIONS.map((cert, i) => (
            <div key={i} className="glass rounded-2xl p-6 hover:scale-[1.01] transition-all duration-300" style={{ borderLeft: `3px solid ${cert.color}` }}>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${cert.color}10`, border: `1px solid ${cert.color}30` }}>
                  <cert.icon size={22} style={{ color: cert.color }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-white mb-1">{cert.name}</h3>
                  <p className="font-mono text-xs" style={{ color: cert.color }}>{cert.issuer}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="font-mono text-xs text-white/40 flex items-center gap-1"><Calendar size={10} />Issued: {cert.issued}</span>
                    {cert.credentialId && <span className="font-mono text-xs text-white/30">ID: {cert.credentialId}</span>}
                  </div>
                  <p className="text-white/50 text-xs mt-2 leading-relaxed">{cert.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── PUBLICATIONS ── */}
      <section id="publications" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="06. research" title="Publications & Research" subtitle="Technical write-ups and research contributions to the security community." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PUBLICATIONS.map((pub, i) => (
            <a key={i} href={pub.url} target="_blank" rel="noopener noreferrer"
              className="glass rounded-2xl p-6 hover:scale-[1.02] transition-all duration-300 group block"
              style={{ border: `1px solid ${pub.color}20` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: `${pub.color}10`, border: `1px solid ${pub.color}30` }}>
                  <FileText size={18} style={{ color: pub.color }} />
                </div>
                <ExternalLink size={14} className="text-white/20 group-hover:text-neon-green transition-colors" />
              </div>
              <h3 className="font-bold text-white mb-1 group-hover:text-neon-green transition-colors">{pub.title}</h3>
              <div className="flex items-center gap-3 mb-3">
                <span className="font-mono text-xs" style={{ color: pub.color }}>{pub.source}</span>
                <span className="font-mono text-xs text-white/30 flex items-center gap-1"><Calendar size={10} />{pub.date}</span>
              </div>
              <p className="text-white/60 text-sm leading-relaxed mb-4">{pub.desc}</p>
              <div className="flex flex-wrap gap-2">
                {pub.tags.map(tag => <SkillTag key={tag} skill={tag} color={pub.color} />)}
              </div>
            </a>
          ))}
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── EDUCATION ── */}
      <section id="education" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="07. education" title="Academic Background" subtitle="Building theoretical foundations alongside practical skills." />
        <div className="max-w-3xl mx-auto space-y-6">
          {EDUCATION.map((edu, i) => (
            <div key={i} className="glass rounded-2xl p-6" style={{ borderLeft: `3px solid ${edu.color}` }}>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${edu.color}10`, border: `1px solid ${edu.color}30` }}>
                  <edu.icon size={22} style={{ color: edu.color }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg" style={{ color: edu.color }}>{edu.institution}</h3>
                  <p className="text-white/80 text-sm mb-1">{edu.degree}</p>
                  <span className="font-mono text-xs text-white/40 flex items-center gap-1 mb-3"><Calendar size={10} />{edu.duration}</span>
                  <div className="flex flex-wrap gap-2">
                    {edu.courses.map(course => (
                      <span key={course} className="font-mono text-xs px-2.5 py-1 rounded-full border text-white/50"
                        style={{ borderColor: `${edu.color}30`, background: `${edu.color}08` }}>{course}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div className="glass rounded-2xl p-6" style={{ borderLeft: '3px solid #bf5af2' }}>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 border" style={{ background: '#bf5af210', borderColor: '#bf5af230' }}>
                <Languages size={22} className="text-neon-purple" />
              </div>
              <div>
                <h3 className="font-bold text-neon-purple mb-2">Languages</h3>
                <div className="flex gap-3 flex-wrap">
                  <SkillTag skill="English" color="#bf5af2" />
                  <SkillTag skill="Hindi" color="#bf5af2" />
                  <SkillTag skill="Chinese (Simplified)" color="#bf5af2" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Separator className="bg-neon-green/10 max-w-7xl mx-auto" />

      {/* ── CONTACT ── */}
      <section id="contact" className="py-24 px-4 max-w-7xl mx-auto">
        <SectionHeader label="08. contact" title="Get In Touch" subtitle="Open to red team engagements, research collaborations, and security consulting." />
        <div className="max-w-2xl mx-auto">
          <div className="glass-green rounded-2xl p-8 text-center">
            <div className="font-mono text-sm mb-6 text-left bg-black/40 rounded-xl p-5 border border-neon-green/10">
              <p className="text-white/30 mb-2"># reach out</p>
              <p className="text-neon-green"><span className="text-neon-cyan">const</span> <span className="text-white">contact</span> <span className="text-white/50">=</span> {'{'}</p>
              <p className="pl-4 text-neon-green"><span className="text-neon-purple">linkedin</span><span className="text-white/50">:</span> <span className="text-yellow-400">'linkedin.com/in/amit-panghal'</span><span className="text-white/50">,</span></p>
              <p className="pl-4 text-neon-green"><span className="text-neon-purple">blog</span><span className="text-white/50">:</span> <span className="text-yellow-400">'tx0actical.github.io'</span><span className="text-white/50">,</span></p>
              <p className="pl-4 text-neon-green"><span className="text-neon-purple">team</span><span className="text-white/50">:</span> <span className="text-yellow-400">'Sid3Chann3l'</span></p>
              <p className="text-neon-green">{'}'}</p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="https://www.linkedin.com/in/amit-panghal/" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 px-6 py-3 rounded-xl font-mono text-sm font-bold transition-all hover:scale-105 bg-neon-green text-black glow-green">
                <Linkedin size={16} />LinkedIn
              </a>
              <a href="https://tx0actical.github.io" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 px-6 py-3 rounded-xl font-mono text-sm font-bold transition-all hover:scale-105 border border-neon-cyan/50 text-neon-cyan hover:bg-neon-cyan/10">
                <Globe size={16} />Research Blog
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="footer-premium relative pt-16 pb-8 px-4 mt-0" style={{ background: 'rgba(0,0,0,0.98)' }}>
        {/* Background grid accent */}
        <div className="absolute inset-0 hex-pattern opacity-30 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          {/* Main footer grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">

            {/* ── COL 1: Brand ── */}
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <LogoIcon size={44} />
                <div>
                  <p className="font-mono font-bold text-white tracking-widest text-sm">AMIT PANGHAL</p>
                  <p className="font-mono text-neon-green/60 text-xs tracking-widest mt-0.5">SECURITY RESEARCHER</p>
                </div>
              </div>
              <p className="text-white/40 text-sm leading-relaxed font-mono">
                Offensive security researcher specialising in Windows Internals, Red Team operations, and adversary emulation.
              </p>
              {/* Cert badges */}
              <div className="flex flex-wrap gap-2">
                {['CRTP', 'Security+', 'CRTE'].map(c => (
                  <span key={c} className="font-mono text-xs px-2.5 py-1 rounded-md border border-neon-green/20 text-neon-green/60 bg-neon-green/5">{c}</span>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
                <span className="font-mono text-neon-green text-xs tracking-wider">Available · New Delhi, India</span>
              </div>
            </div>

            {/* ── COL 2: Nav Links ── */}
            <div>
              <p className="font-mono text-white/30 text-xs tracking-widest uppercase mb-5">
                <span className="text-neon-green mr-2">//</span>Navigation
              </p>
              <div className="grid grid-cols-2 gap-2">
                {NAV_LINKS.map((link, i) => (
                  <button
                    key={link.id}
                    onClick={() => document.getElementById(link.id)?.scrollIntoView({ behavior: 'smooth' })}
                    className="flex items-center gap-2 text-white/40 hover:text-neon-green font-mono text-xs py-1.5 transition-colors group text-left"
                  >
                    <span className="text-neon-green/30 group-hover:text-neon-green/70 transition-colors">
                      {String(i + 1).padStart(2, '0')}.
                    </span>
                    {link.label}
                  </button>
                ))}
              </div>
            </div>

            {/* ── COL 3: Socials ── */}
            <div>
              <p className="font-mono text-white/30 text-xs tracking-widest uppercase mb-5">
                <span className="text-neon-green mr-2">//</span>Connect
              </p>
              <div className="space-y-3">
                <a href="https://www.linkedin.com/in/amit-panghal/" target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-xl border border-white/5 hover:border-neon-cyan/30 hover:bg-neon-cyan/5 transition-all group">
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-neon-cyan/10 transition-colors">
                    <Linkedin size={15} className="text-white/40 group-hover:text-neon-cyan transition-colors" />
                  </div>
                  <div>
                    <p className="font-mono text-xs text-white/70 group-hover:text-white transition-colors">LinkedIn</p>
                    <p className="font-mono text-xs text-white/30">linkedin.com/in/amit-panghal</p>
                  </div>
                </a>
                <a href="https://tx0actical.github.io" target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-xl border border-white/5 hover:border-neon-green/30 hover:bg-neon-green/5 transition-all group">
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-neon-green/10 transition-colors">
                    <Globe size={15} className="text-white/40 group-hover:text-neon-green transition-colors" />
                  </div>
                  <div>
                    <p className="font-mono text-xs text-white/70 group-hover:text-white transition-colors">Research Blog</p>
                    <p className="font-mono text-xs text-white/30">tx0actical.github.io</p>
                  </div>
                </a>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="h-px w-full mb-8"
            style={{ background: 'linear-gradient(90deg, transparent, rgba(0,255,65,0.15) 30%, rgba(0,255,255,0.1) 70%, transparent)' }} />

          {/* Bottom bar */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Left: logo + copyright */}
            <div className="flex items-center gap-3">
              <LogoIcon size={22} />
              <p className="font-mono text-white/30 text-xs">
                © {new Date().getFullYear()} <span className="text-white/50 font-semibold">Amit Panghal</span>
                <span className="text-white/20 mx-2">·</span>
                <span className="text-white/25">All rights reserved.</span>
              </p>
            </div>

            {/* Center: tagline */}
            <p className="font-mono text-white/15 text-xs tracking-widest uppercase hidden md:block">
              Hack the Planet · Stay Curious
            </p>

            {/* Right: location + status */}
            <div className="flex items-center gap-4">
              <span className="font-mono text-white/25 text-xs flex items-center gap-1.5">
                <MapPin size={10} className="text-neon-green/50" />
                New Delhi, India
              </span>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-neon-green/15 bg-neon-green/5">
                <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
                <span className="font-mono text-neon-green/60 text-xs">ONLINE</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
